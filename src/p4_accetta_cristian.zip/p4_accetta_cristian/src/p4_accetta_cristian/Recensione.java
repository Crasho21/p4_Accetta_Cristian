package p4_accetta_cristian;
import java.util.Calendar;
/**
 * Classe per definire l'oggetto Recensione
 * @author Accetta Cristian
 */
public class Recensione{
    /** Attributi */
    private String autore;
    private String titolo;
    private float valutazione;
    private String commento;
    private String versioneApp;
    private String dispositivo;
    private Calendar data;
}