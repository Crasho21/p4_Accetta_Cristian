package p4_accetta_cristian;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
/**
 * Classe per gestire il salvataggio su file dei dati in modo tale da renderli permanenti
 * @author Accetta Cristian
 */
public class FileIO {

	private String file;
	private ArrayList<Gruppo> gruppi;

	public FileIO(String f){
		file = f;
		gruppi = new ArrayList<Gruppo>();
	}
	/**
	 * Funzione per salvare dati permanentemente su file
	 * 
	 * @param dati I dati da salvare
	 */
	public void salvaDati(ArrayList<Gruppo> dati){
		try{
			FileOutputStream fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(dati);
			oos.close();
			fos.close();
		} catch(Exception e){
			e.printStackTrace();
		}	
	}
	/**
	 * Funzione per leggere i dati salvati su file
	 * 
	 * @return gruppi L'ArrayList contenente i gruppi letti da file
	 */
	public ArrayList<Gruppo> leggiDati(){
		try{
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			gruppi = (ArrayList<Gruppo>) ois.readObject();
			ois.close();
			fis.close();
		} catch(Exception e){
			e.printStackTrace();
		}
		return gruppi;
	}
}
