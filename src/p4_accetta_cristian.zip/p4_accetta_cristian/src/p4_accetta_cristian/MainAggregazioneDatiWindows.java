package p4_accetta_cristian;
import java.util.ArrayList;
/**
 * Classe di prova della funzione aggregazioneDati con dati del Windows Store
 * @author Accetta Cristian
 */
public class MainAggregazioneDatiWindows {

	public static void main(String[] args) {
		// Creo dei dati di prova
		ArrayList<App> apps = new ArrayList<App>();
		for(int i = 0; i < 5; i++){
			System.out.println("Valori generati:");
			ArrayList<Integer> daily = new ArrayList<Integer>();
			for(int j = 0; j < (int)(Math.random() * 10 + 1); j++){
				daily.add((int)(Math.random() * 100));
				System.out.println(daily.get(j));
			}
			ArrayList<Integer> tot = new ArrayList<Integer>();
			tot.add((int)(Math.random() * 100));
			System.out.println(tot.get(0));
			Dati d = new Dati();
			d.setProvenienza(Dati.WINDOWS_STORE);
    		d.setOverview_dailyUserInstalls(daily);
    		d.setCountry_dailyUserInstalls(daily);
    		d.setOsVersion_dailyUserInstalls(daily);
    		d.setFailure_count(tot);
			App a = new App();
			a.setDati(d);
			apps.add(a);
		}
		// Inserisco i dati in un gruppo
		Gruppo g = new  Gruppo("Prova");
		g.setApps(apps);
		// Eseguo l'aggregazione dei dati
		g.aggregazioneDati();
		// Stampo i dati per controllare che siano corretti
		System.out.println("Dati aggregati:\n" + g.getDatiAggregati().getOverview_dailyUserInstalls()
				+ "\n" + g.getDatiAggregati().getCountry_dailyUserInstalls() + "\n"
				+ g.getDatiAggregati().getOsVersion_dailyUserInstalls() + "\n"
				+ g.getDatiAggregati().getFailure_count());
	}

}
