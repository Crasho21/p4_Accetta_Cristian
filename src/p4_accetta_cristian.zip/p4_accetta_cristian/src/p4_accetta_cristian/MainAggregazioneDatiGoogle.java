package p4_accetta_cristian;
import java.util.ArrayList;
/**
 * Classe di prova della funzione aggregazioneDati con dati del Google Play Store
 * @author Accetta Cristian
 */
public class MainAggregazioneDatiGoogle {

	public static void main(String[] args) {
		// Creo dei dati di prova
		ArrayList<App> apps = new ArrayList<App>();
		for(int i = 0; i < 5; i++){
			System.out.println("Valori generati:");
			ArrayList<Integer> daily = new ArrayList<Integer>();
			for(int j = 0; j < (int)(Math.random() * 10 + 1); j++){
				daily.add((int)(Math.random() * 100));
				System.out.println(daily.get(j));
			}
			ArrayList<Integer> tot = new ArrayList<Integer>();
			tot.add((int)(Math.random() * 100));
			System.out.println(tot.get(0));
			Dati d = new Dati();
			d.setProvenienza(Dati.GOOGLE_PLAY_STORE);
    		d.setOverview_dailyUserInstalls(daily);
    		d.setOverview_totUserInstalls(tot);
    		d.setOverview_dailyUserUninstalls(daily);
    		d.setOverview_activeDeviceInstalls(daily);
    		d.setCarrier_totUserInstalls(tot);
    		d.setCarrier_dailyUserInstalls(daily);
    		d.setCarrier_dailyUserUninstalls(daily);
    		d.setCarrier_activeDeviceInstalls(daily);
    		d.setCountry_dailyUserInstalls(daily);
    		d.setCountry_totUserInstalls(tot);
    		d.setCountry_dailyUserUninstalls(daily);
    		d.setCountry_activeDeviceInstalls(daily);
    		d.setDevice_totUserInstalls(tot);
    		d.setDevice_dailyUserInstalls(daily);
    		d.setDevice_dailyUserUninstalls(daily);
    		d.setDevice_activeDeviceInstalls(daily);
    		d.setLang_totUserInstalls(tot);
    		d.setLang_dailyUserInstalls(daily);
    		d.setLang_dailyUserUninstalls(daily);
    		d.setLang_activeDeviceInstalls(daily);
    		d.setOsVersion_dailyUserInstalls(daily);
    		d.setOsVersion_totUserInstalls(tot);
    		d.setOsVersion_dailyUserUninstalls(daily);
    		d.setOsVersion_activeDeviceInstalls(daily);
    		d.setTablet_totUserInstalls(tot);
    		d.setTablet_dailyUserInstalls(daily);
    		d.setTablet_dailyUserUninstalls(daily);
    		d.setTablet_activeDeviceInstalls(daily);
			App a = new App();
			a.setDati(d);
			apps.add(a);
		}
		// Inserisco i dati in un gruppo
		Gruppo g = new  Gruppo("Prova");
		g.setApps(apps);
		// Eseguo l'aggregazione dei dati
		g.aggregazioneDati();
		// Stampo alcuni dati per controllare che siano corretti
		System.out.println(g.getDatiAggregati().toString());
	}

}
