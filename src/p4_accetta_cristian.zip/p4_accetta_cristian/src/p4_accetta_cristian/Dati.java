package p4_accetta_cristian;
import java.util.ArrayList;
/**
 * Classe per definire l'oggetto Dati
 * @author Accetta Cristian
 */
public class Dati{
	
	/** Constanti per indicare la provenienza dell'App (cioè da quale AppStore è stata salvata)
	 * GOOGLE_PLAY_STORE = 1
	 * APPLE_STORE = 2
	 * WINDOWS_STORE = 3 */
	public final static int GOOGLE_PLAY_STORE = 1;
	public final static int APPLE_STORE = 2;
	public final static int WINDOWS_STORE = 3;
	
    /** Attributi */
	private String versione;
	private int provenienza;

	//Overview
	private ArrayList<String> overview_data;
	private ArrayList<Integer> overview_dailyUserInstalls;	//Anche WinStore (install)
	private ArrayList<Integer> overview_totUserInstalls;	
	private ArrayList<Integer> overview_dailyUserUninstalls;
	private ArrayList<Integer> overview_activeDeviceInstalls;
	
	//Aggregazione per carrier
	private ArrayList<String> carrier_data;
	private ArrayList<Integer> carrier_totUserInstalls;
	private ArrayList<Integer> carrier_dailyUserInstalls;
	private ArrayList<Integer> carrier_dailyUserUninstalls;
	private ArrayList<Integer> carrier_activeDeviceInstalls;

	//Aggregazione per paese
	private ArrayList<String> country_data;
	private ArrayList<Integer> country_dailyUserInstalls;	//Anche WinStore (install_markets)
	private ArrayList<Integer> country_totUserInstalls;
	private ArrayList<Integer> country_dailyUserUninstalls;
	private ArrayList<Integer> country_activeDeviceInstalls;
	
	//Aggregazione per device
	private ArrayList<String> device_data;
	private ArrayList<Integer> device_totUserInstalls;
	private ArrayList<Integer> device_dailyUserInstalls;
	private ArrayList<Integer> device_dailyUserUninstalls;
	private ArrayList<Integer> device_activeDeviceInstalls;
	
	//Aggregazione per lingua
	private ArrayList<String> lang_data;
	private ArrayList<Integer> lang_totUserInstalls;
	private ArrayList<Integer> lang_dailyUserInstalls;
	private ArrayList<Integer> lang_dailyUserUninstalls;
	private ArrayList<Integer> lang_activeDeviceInstalls;
	
	//Aggregazione per versione OS
	private ArrayList<String> osVersion_data;
	private ArrayList<Integer> osVersion_dailyUserInstalls;	//Anche WinStore (acquisition_os)
	private ArrayList<Integer> osVersion_totUserInstalls;
	private ArrayList<Integer> osVersion_dailyUserUninstalls;
	private ArrayList<Integer> osVersion_activeDeviceInstalls;
	
	//Aggregazione per tablet
	private ArrayList<String> tablet_data;
	private ArrayList<Integer> tablet_totUserInstalls;
	private ArrayList<Integer> tablet_dailyUserInstalls;
	private ArrayList<Integer> tablet_dailyUserUninstalls;
	private ArrayList<Integer> tablet_activeDeviceInstalls;
	
	
	//SOLO WinStore
	private ArrayList<String> failure_data;
	private ArrayList<Integer> failure_count;	//Da failure
	
	public String getVersione() {
		return versione;
	}
	
	public void setVersione(String versione) {
		this.versione = versione;
	}
	
	public int getProvenienza() {
		return provenienza;
	}
	
	public void setProvenienza(int provenienza) {
		this.provenienza = provenienza;
	}
	
	public ArrayList<String> getOverview_data() {
		return overview_data;
	}
	
	public void setOverview_data(ArrayList<String> overview_data) {
		this.overview_data = overview_data;
	}
	
	public ArrayList<Integer> getOverview_dailyUserInstalls() {
		return overview_dailyUserInstalls;
	}
	
	public void setOverview_dailyUserInstalls(ArrayList<Integer> overview_dailyUserInstalls) {
		this.overview_dailyUserInstalls = overview_dailyUserInstalls;
	}
	
	public ArrayList<Integer> getOverview_totUserInstalls() {
		return overview_totUserInstalls;
	}
	
	public void setOverview_totUserInstalls(ArrayList<Integer> overview_totUserInstalls) {
		this.overview_totUserInstalls = overview_totUserInstalls;
	}
	
	public ArrayList<Integer> getOverview_dailyUserUninstalls() {
		return overview_dailyUserUninstalls;
	}
	
	public void setOverview_dailyUserUninstalls(ArrayList<Integer> overview_dailyUserUninstalls) {
		this.overview_dailyUserUninstalls = overview_dailyUserUninstalls;
	}
	
	public ArrayList<Integer> getOverview_activeDeviceInstalls() {
		return overview_activeDeviceInstalls;
	}
	
	public void setOverview_activeDeviceInstalls(ArrayList<Integer> overview_activeDeviceInstalls) {
		this.overview_activeDeviceInstalls = overview_activeDeviceInstalls;
	}
	
	public ArrayList<String> getCarrier_data() {
		return carrier_data;
	}
	
	public void setCarrier_data(ArrayList<String> carrier_data) {
		this.carrier_data = carrier_data;
	}
	
	public ArrayList<Integer> getCarrier_totUserInstalls() {
		return carrier_totUserInstalls;
	}
	
	public void setCarrier_totUserInstalls(ArrayList<Integer> carrier_totUserInstalls) {
		this.carrier_totUserInstalls = carrier_totUserInstalls;
	}
	
	public ArrayList<Integer> getCarrier_dailyUserInstalls() {
		return carrier_dailyUserInstalls;
	}
	
	public void setCarrier_dailyUserInstalls(ArrayList<Integer> carrier_dailyUserInstalls) {
		this.carrier_dailyUserInstalls = carrier_dailyUserInstalls;
	}
	
	public ArrayList<Integer> getCarrier_dailyUserUninstalls() {
		return carrier_dailyUserUninstalls;
	}
	
	public void setCarrier_dailyUserUninstalls(ArrayList<Integer> carrier_dailyUserUninstalls) {
		this.carrier_dailyUserUninstalls = carrier_dailyUserUninstalls;
	}
	
	public ArrayList<Integer> getCarrier_activeDeviceInstalls() {
		return carrier_activeDeviceInstalls;
	}
	
	public void setCarrier_activeDeviceInstalls(ArrayList<Integer> carrier_activeDeviceInstalls) {
		this.carrier_activeDeviceInstalls = carrier_activeDeviceInstalls;
	}
	
	public ArrayList<String> getCountry_data() {
		return country_data;
	}
	
	public void setCountry_data(ArrayList<String> country_data) {
		this.country_data = country_data;
	}
	
	public ArrayList<Integer> getCountry_dailyUserInstalls() {
		return country_dailyUserInstalls;
	}
	
	public void setCountry_dailyUserInstalls(ArrayList<Integer> country_dailyUserInstalls) {
		this.country_dailyUserInstalls = country_dailyUserInstalls;
	}
	
	public ArrayList<Integer> getCountry_totUserInstalls() {
		return country_totUserInstalls;
	}
	
	public void setCountry_totUserInstalls(ArrayList<Integer> country_totUserInstalls) {
		this.country_totUserInstalls = country_totUserInstalls;
	}
	
	public ArrayList<Integer> getCountry_dailyUserUninstalls() {
		return country_dailyUserUninstalls;
	}
	
	public void setCountry_dailyUserUninstalls(ArrayList<Integer> country_dailyUserUninstalls) {
		this.country_dailyUserUninstalls = country_dailyUserUninstalls;
	}
	
	public ArrayList<Integer> getCountry_activeDeviceInstalls() {
		return country_activeDeviceInstalls;
	}
	
	public void setCountry_activeDeviceInstalls(ArrayList<Integer> country_activeDeviceInstalls) {
		this.country_activeDeviceInstalls = country_activeDeviceInstalls;
	}
	
	public ArrayList<String> getDevice_data() {
		return device_data;
	}
	
	public void setDevice_data(ArrayList<String> device_data) {
		this.device_data = device_data;
	}
	
	public ArrayList<Integer> getDevice_totUserInstalls() {
		return device_totUserInstalls;
	}
	
	public void setDevice_totUserInstalls(ArrayList<Integer> device_totUserInstalls) {
		this.device_totUserInstalls = device_totUserInstalls;
	}
	
	public ArrayList<Integer> getDevice_dailyUserInstalls() {
		return device_dailyUserInstalls;
	}
	
	public void setDevice_dailyUserInstalls(ArrayList<Integer> device_dailyUserInstalls) {
		this.device_dailyUserInstalls = device_dailyUserInstalls;
	}
	
	public ArrayList<Integer> getDevice_dailyUserUninstalls() {
		return device_dailyUserUninstalls;
	}
	
	public void setDevice_dailyUserUninstalls(ArrayList<Integer> device_dailyUserUninstalls) {
		this.device_dailyUserUninstalls = device_dailyUserUninstalls;
	}
	
	public ArrayList<Integer> getDevice_activeDeviceInstalls() {
		return device_activeDeviceInstalls;
	}
	
	public void setDevice_activeDeviceInstalls(ArrayList<Integer> device_activeDeviceInstalls) {
		this.device_activeDeviceInstalls = device_activeDeviceInstalls;
	}
	
	public ArrayList<String> getLang_data() {
		return lang_data;
	}
	
	public void setLang_data(ArrayList<String> lang_data) {
		this.lang_data = lang_data;
	}
	
	public ArrayList<Integer> getLang_totUserInstalls() {
		return lang_totUserInstalls;
	}
	
	public void setLang_totUserInstalls(ArrayList<Integer> lang_totUserInstalls) {
		this.lang_totUserInstalls = lang_totUserInstalls;
	}
	
	public ArrayList<Integer> getLang_dailyUserInstalls() {
		return lang_dailyUserInstalls;
	}
	
	public void setLang_dailyUserInstalls(ArrayList<Integer> lang_dailyUserInstalls) {
		this.lang_dailyUserInstalls = lang_dailyUserInstalls;
	}
	
	public ArrayList<Integer> getLang_dailyUserUninstalls() {
		return lang_dailyUserUninstalls;
	}
	
	public void setLang_dailyUserUninstalls(ArrayList<Integer> lang_dailyUserUninstalls) {
		this.lang_dailyUserUninstalls = lang_dailyUserUninstalls;
	}
	
	public ArrayList<Integer> getLang_activeDeviceInstalls() {
		return lang_activeDeviceInstalls;
	}
	
	public void setLang_activeDeviceInstalls(ArrayList<Integer> lang_activeDeviceInstalls) {
		this.lang_activeDeviceInstalls = lang_activeDeviceInstalls;
	}
	
	public ArrayList<String> getOsVersion_data() {
		return osVersion_data;
	}
	
	public void setOsVersion_data(ArrayList<String> osVersion_data) {
		this.osVersion_data = osVersion_data;
	}
	
	public ArrayList<Integer> getOsVersion_dailyUserInstalls() {
		return osVersion_dailyUserInstalls;
	}
	
	public void setOsVersion_dailyUserInstalls(ArrayList<Integer> osVersion_dailyUserInstalls) {
		this.osVersion_dailyUserInstalls = osVersion_dailyUserInstalls;
	}
	
	public ArrayList<Integer> getOsVersion_totUserInstalls() {
		return osVersion_totUserInstalls;
	}
	
	public void setOsVersion_totUserInstalls(ArrayList<Integer> osVersion_totUserInstalls) {
		this.osVersion_totUserInstalls = osVersion_totUserInstalls;
	}
	
	public ArrayList<Integer> getOsVersion_dailyUserUninstalls() {
		return osVersion_dailyUserUninstalls;
	}
	
	public void setOsVersion_dailyUserUninstalls(ArrayList<Integer> osVersion_dailyUserUninstalls) {
		this.osVersion_dailyUserUninstalls = osVersion_dailyUserUninstalls;
	}
	
	public ArrayList<Integer> getOsVersion_activeDeviceInstalls() {
		return osVersion_activeDeviceInstalls;
	}
	
	public void setOsVersion_activeDeviceInstalls(ArrayList<Integer> osVersion_activeDeviceInstalls) {
		this.osVersion_activeDeviceInstalls = osVersion_activeDeviceInstalls;
	}
	
	public ArrayList<String> getTablet_data() {
		return tablet_data;
	}
	
	public void setTablet_data(ArrayList<String> tablet_data) {
		this.tablet_data = tablet_data;
	}
	
	public ArrayList<Integer> getTablet_totUserInstalls() {
		return tablet_totUserInstalls;
	}
	
	public void setTablet_totUserInstalls(ArrayList<Integer> tablet_totUserInstalls) {
		this.tablet_totUserInstalls = tablet_totUserInstalls;
	}
	
	public ArrayList<Integer> getTablet_dailyUserInstalls() {
		return tablet_dailyUserInstalls;
	}
	
	public void setTablet_dailyUserInstalls(ArrayList<Integer> tablet_dailyUserInstalls) {
		this.tablet_dailyUserInstalls = tablet_dailyUserInstalls;
	}
	
	public ArrayList<Integer> getTablet_dailyUserUninstalls() {
		return tablet_dailyUserUninstalls;
	}
	
	public void setTablet_dailyUserUninstalls(ArrayList<Integer> tablet_dailyUserUninstalls) {
		this.tablet_dailyUserUninstalls = tablet_dailyUserUninstalls;
	}
	
	public ArrayList<Integer> getTablet_activeDeviceInstalls() {
		return tablet_activeDeviceInstalls;
	}
	
	public void setTablet_activeDeviceInstalls(ArrayList<Integer> tablet_activeDeviceInstalls) {
		this.tablet_activeDeviceInstalls = tablet_activeDeviceInstalls;
	}
	
	public ArrayList<String> getFailure_data() {
		return failure_data;
	}
	
	public void setFailure_data(ArrayList<String> failure_data) {
		this.failure_data = failure_data;
	}
	
	public ArrayList<Integer> getFailure_count() {
		return failure_count;
	}
	
	public void setFailure_count(ArrayList<Integer> failure_count) {
		this.failure_count = failure_count;
	}

	@Override
	public String toString() {
		return "Dati:\n" + this.overview_dailyUserInstalls + "\n" + 
				this.overview_dailyUserUninstalls + "\n" +
				this.overview_totUserInstalls + "\n" +
				this.overview_activeDeviceInstalls;
	}
	
}