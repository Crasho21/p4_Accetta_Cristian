package p4_accetta_cristian;
/**
 * Classe di prova per l'interfaccia grafica, contiene solo creazioneGruppo e cancellazioneGruppo, 
 * aggregazioneDati non ha bisogno di interfaccia grafica, dato che è una sottofunzione
 * @author Accetta Cristian
 */
public class MainGUI {

	public static void main(String[] args) {
		Sistema sistema = new Sistema("Interfaccia Grafica");
	}
}
