package p4_accetta_cristian;
/**
 * Classe per definire l'oggetto Credenziali
 * @author Accetta Cristian
 */
public class Credenziali{
    /** Attributi */
    private String username;
    private String password;
}