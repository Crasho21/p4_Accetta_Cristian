package p4_accetta_cristian;
/**
 * Classe di prova per la funzione creazioneGruppo
 * @author Accetta Cristian
 */
public class MainCreazioneGruppo {

	public static void main(String args[]){
		Sistema sistema = new Sistema();
		sistema.creazioneGruppo();
		sistema.creazioneGruppo();
		sistema.creazioneGruppo();
	}
}
