package p4_accetta_cristian_uc_4_5_13;
/**
 * Classe per definire l'oggetto Credenziali
 * @author Accetta Cristian
 */
public class Credenziali{
    /** Attributi */
    private String username;
    private String password;
}