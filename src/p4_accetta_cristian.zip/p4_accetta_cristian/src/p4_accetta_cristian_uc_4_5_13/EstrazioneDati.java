package p4_accetta_cristian_uc_4_5_13;
/**
 * Classe per implementare la funzione EstrazioneDati negli AppStore supportati
 * @author Accetta Cristian
 */
public class EstrazioneDati implements Visitor{
    /** Attributi */
    private App app;
    /**
     * Funzione visit del Visitor per il GoogleStore
     *
     * @param google AppStore specifico
     */
    public void visit(GoogleStore google){
         
    }
    /**
     * Funzione visit del Visitor per l'AppleStore
     *
     * @param apple AppStore specifico
     */
    public void visit(AppleStore apple){
         
    }
    /**
     * Funzione visit del Visitor il WinStore
     *
     * @param win AppStore specifico
     */
    public void visit(WinStore win){
    	
    }
    
}