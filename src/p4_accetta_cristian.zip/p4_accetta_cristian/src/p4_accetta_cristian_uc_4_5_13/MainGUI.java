package p4_accetta_cristian_uc_4_5_13;
/**
 * Classe di prova per l'interfaccia grafica, contiene solo creazioneGruppo e cancellazioneGruppo, aggregazioneDati non ha bisogno di 
 * interfaccia grafica, dato che non ha interazioni con l'utente ed è una sottofunzione
 * @author Accetta Cristian
 */
public class MainGUI {

	public static void main(String[] args) {
		Sistema sistema = new Sistema("Interfaccia Grafica");
	}
	
}
